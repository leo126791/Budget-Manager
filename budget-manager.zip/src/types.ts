export type NavigationTab = 'dashboard' | 'transactions' | 'analytics' | 'settings';

export type TransactionType = 'expense' | 'income' | 'transfer';

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: TransactionType;
  category: string;
  categoryIcon: string;
  categoryBg: string;
  categoryColor: string;
  account: string;
  date: string; // YYYY-MM-DD
  dateDisplay: string; // e.g. "今日 · 09月09日 星期三"
  time: string; // e.g. "12:35"
  tag?: string; // e.g. "#午餐"
  note?: string; // e.g. "個人日常", "忠孝復興至市政府"
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
  budget: number;
  spent: number;
  percentage: number;
  trend: string;
}

export interface Subscription {
  id: string;
  name: string;
  billingCycle: 'monthly' | 'yearly';
  amount: number;
  monthlyEquivalent: number;
  scheduleDescription: string;
  iconType: 'letter' | 'icon';
  iconLetter?: string;
  iconName?: string;
  accentColor: string;
  badgeText: string;
}

export interface SavingsGoal {
  id: string;
  title: string;
  emoji: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  progressPercent: number;
}

export interface AppSettings {
  darkMode: boolean;
  theme: string;
  language: string;
  haptics: boolean;
  autoCloudBackup: boolean;
  lastBackupTime: string;
  vaultBudget: number;
  dynamicBudgetPool: boolean;
  currency: string;
  betaTesting: boolean;
  betaFeatures: {
    incomeTracking: boolean;
    keywordSearch: boolean;
    subscriptions: boolean;
    paymentMethods: boolean;
    savingsGoals: boolean;
    dragMoveRecords: boolean;
  };
}
