import React, { useState, useEffect } from 'react';
import { NavigationTab, Transaction, AppSettings } from './types';
import {
  initialTransactions,
  initialCategories,
  initialSubscriptions,
  initialSavingsGoals,
  initialSettings,
} from './data/initialData';
import { StatusBar } from './components/StatusBar';
import { AppHeader } from './components/AppHeader';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/DashboardView';
import { TransactionsView } from './components/TransactionsView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';
import { AddTransactionModal } from './components/AddTransactionModal';
import { AndroidKotlinModal } from './components/AndroidKotlinModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isKotlinModalOpen, setIsKotlinModalOpen] = useState<boolean>(false);

  // App settings state with localStorage persistence
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('budget_manager_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return initialSettings;
  });

  // Transactions state with localStorage persistence
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('budget_manager_transactions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return initialTransactions;
  });

  const [subscriptions] = useState(initialSubscriptions);
  const [savingsGoals] = useState(initialSavingsGoals);
  const [categories] = useState(initialCategories);

  // Sync settings to localStorage
  useEffect(() => {
    localStorage.setItem('budget_manager_settings', JSON.stringify(settings));
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  // Sync transactions to localStorage
  useEffect(() => {
    localStorage.setItem('budget_manager_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const handleUpdateSettings = (newPartial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newPartial }));
  };

  const handleAddTransaction = (newTx: Omit<Transaction, 'id'>) => {
    const created: Transaction = {
      ...newTx,
      id: `tx-${Date.now()}`,
    };
    setTransactions([created, ...transactions]);
  };

  // Real CSV Export feature
  const handleExportCsv = () => {
    const headers = ['日期', '時間', '類型', '分類', '標題/備註', '金額(TWD)', '帳戶', '標籤'];
    const rows = transactions.map((t) => [
      t.date,
      t.time,
      t.type === 'expense' ? '支出' : '收入',
      t.category,
      `"${t.title.replace(/"/g, '""')}"`,
      t.amount,
      t.account,
      t.tag || '',
    ]);

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Budget_Manager_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const darkMode = settings.darkMode;

  return (
    <div
      className={`min-h-screen ${
        darkMode ? 'dark bg-[#101412] text-[#e0e3df]' : 'bg-[#f4f6f4] text-[#191c1d]'
      } font-sans antialiased transition-colors`}
    >
      {/* Mobile Container (Material 3 Mobile Viewport max-w-md) */}
      <div
        className={`w-full max-w-md mx-auto ${
          darkMode ? 'bg-[#101412]' : 'bg-[#f4f6f4]'
        } min-h-screen relative pb-28 flex flex-col transition-colors shadow-2xl`}
      >
        {/* Android Material 3 Status Bar */}
        <StatusBar darkMode={darkMode} />

        {/* Top App Header */}
        <AppHeader
          currentTab={currentTab}
          darkMode={darkMode}
          onOpenKotlinModal={() => setIsKotlinModalOpen(true)}
          onNavigateTab={(tab) => setCurrentTab(tab)}
          searchQuery={searchQuery}
          onSearchChange={(q) => setSearchQuery(q)}
        />

        {/* Main Content View Switcher */}
        <main className="flex-1 px-4 pt-3 overflow-y-auto no-scrollbar">
          {currentTab === 'dashboard' && (
            <DashboardView
              darkMode={darkMode}
              transactions={transactions}
              subscriptions={subscriptions}
              savingsGoals={savingsGoals}
              onNavigateTab={(tab) => setCurrentTab(tab)}
              onOpenAddModal={() => setIsAddModalOpen(true)}
            />
          )}

          {currentTab === 'transactions' && (
            <TransactionsView
              darkMode={darkMode}
              transactions={transactions}
              searchQuery={searchQuery}
              onOpenAddModal={() => setIsAddModalOpen(true)}
            />
          )}

          {currentTab === 'analytics' && (
            <AnalyticsView
              darkMode={darkMode}
              categories={categories}
              onExportCsv={handleExportCsv}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsView
              darkMode={darkMode}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onExportCsv={handleExportCsv}
              onOpenKotlinModal={() => setIsKotlinModalOpen(true)}
            />
          )}
        </main>

        {/* Floating Action Button (記一筆 FAB) */}
        <div className="fixed bottom-20 right-4 sm:right-6 z-30">
          <button
            id="fab-add-transaction"
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className={`h-14 px-5 rounded-full ${
              darkMode
                ? 'bg-[#10b981] hover:bg-[#059669] text-[#002111] shadow-[0_8px_28px_rgba(16,185,129,0.35)]'
                : 'bg-[#346247] hover:bg-[#284f38] text-white shadow-[0_8px_28px_rgba(52,98,71,0.25)]'
            } font-bold flex items-center space-x-2 active:scale-95 transition-all border border-white/10`}
          >
            <span className="material-symbols-outlined text-[24px]">edit_note</span>
            <span className="text-sm tracking-wide">記一筆</span>
          </button>
        </div>

        {/* Material 3 Bottom Navigation Bar */}
        <BottomNav
          currentTab={currentTab}
          onTabChange={(tab) => {
            setCurrentTab(tab);
            setSearchQuery('');
          }}
          darkMode={darkMode}
        />
      </div>

      {/* Add Transaction Modal */}
      <AddTransactionModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleAddTransaction}
        darkMode={darkMode}
      />

      {/* Android Studio Kotlin Jetpack Compose Modal */}
      <AndroidKotlinModal
        isOpen={isKotlinModalOpen}
        onClose={() => setIsKotlinModalOpen(false)}
        darkMode={darkMode}
      />
    </div>
  );
}
