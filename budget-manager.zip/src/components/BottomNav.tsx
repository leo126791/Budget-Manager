import React from 'react';
import { NavigationTab } from '../types';

interface BottomNavProps {
  currentTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  darkMode: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  darkMode,
}) => {
  const tabs: { key: NavigationTab; label: string; icon: string }[] = [
    { key: 'dashboard', label: '總覽', icon: 'grid_view' },
    { key: 'transactions', label: '明細', icon: 'receipt_long' },
    { key: 'analytics', label: '統計', icon: 'monitoring' },
    { key: 'settings', label: '設定', icon: 'settings' },
  ];

  return (
    <nav
      id="bottom-navigation-bar"
      className={`fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto ${
        darkMode
          ? 'bg-[#101412]/95 border-t border-[#28332a]/70 shadow-[0_-4px_20px_rgba(0,0,0,0.4)]'
          : 'bg-white/95 border-t border-neutral-200/80 shadow-[0_-2px_12px_rgba(52,98,71,0.05)]'
      } backdrop-blur-md px-4 py-2 transition-colors`}
    >
      <div className="flex justify-around items-center">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.key;
          return (
            <button
              key={tab.key}
              id={`nav-tab-${tab.key}`}
              type="button"
              onClick={() => onTabChange(tab.key)}
              className={`flex flex-col items-center py-1 transition-all ${
                isActive
                  ? darkMode
                    ? 'text-[#34d399]'
                    : 'text-[#346247]'
                  : darkMode
                  ? 'text-[#88938b] hover:text-[#e0e3df]'
                  : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              <div
                className={`w-12 h-7 rounded-full flex items-center justify-center transition-all ${
                  isActive
                    ? darkMode
                      ? 'bg-[#1b4a31] border border-[#34d399]/30 text-[#34d399]'
                      : 'bg-emerald-100/90 text-[#346247]'
                    : 'bg-transparent text-current'
                }`}
              >
                <span
                  className={`material-symbols-outlined text-[21px] transition-transform ${
                    isActive ? 'fill scale-105' : 'group-hover:scale-110'
                  }`}
                >
                  {tab.icon}
                </span>
              </div>
              <span
                className={`text-[11px] mt-0.5 ${
                  isActive ? 'font-bold' : 'font-medium'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
