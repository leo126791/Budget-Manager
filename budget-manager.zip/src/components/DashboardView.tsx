import React from 'react';
import { Transaction, Subscription, SavingsGoal, NavigationTab } from '../types';

interface DashboardViewProps {
  darkMode: boolean;
  transactions: Transaction[];
  subscriptions: Subscription[];
  savingsGoals: SavingsGoal[];
  onNavigateTab: (tab: NavigationTab) => void;
  onOpenAddModal: () => void;
  onOpenSubscriptionModal?: () => void;
  onOpenGoalModal?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  darkMode,
  transactions,
  subscriptions,
  savingsGoals,
  onNavigateTab,
  onOpenAddModal,
}) => {
  // Recent 3 transactions for today
  const recentTransactions = transactions.slice(0, 3);

  return (
    <div className="flex flex-col w-full gap-4 pb-12">
      {/* Forest Green Hero Savings Card */}
      <section
        id="hero-savings-card"
        className={`relative w-full rounded-2xl p-4 sm:p-5 ${
          darkMode
            ? 'bg-gradient-to-br from-[#1A3E2C] via-[#143223] to-[#0E2419] text-white border border-[#34D399]/25 shadow-[0_12px_32px_rgba(0,0,0,0.45),0_0_24px_rgba(52,211,153,0.12)]'
            : 'bg-gradient-to-br from-[#346247] via-[#1b4a31] to-[#142c1e] text-white shadow-[0_12px_32px_rgba(42,157,143,0.18)]'
        } overflow-hidden transition-all`}
      >
        {/* Ambient organic gradient glow */}
        <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-[#34D399]/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-40 h-40 rounded-full bg-[#015435]/30 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#34D399] tracking-wide">
              預估本月儲蓄 Estimated Savings
            </span>
            <span className="text-[10px] bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] animate-ping" />
              自動計算中
            </span>
          </div>

          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl sm:text-4xl font-bold tracking-tight text-white drop-shadow-sm font-mono">
              $4,250
            </span>
            <span className="text-xs font-semibold text-emerald-300/80">TWD</span>
          </div>

          {/* Financial Progress Bar */}
          <div className="flex flex-col gap-1.5 pt-0.5">
            <div className="flex items-center justify-between text-xs text-emerald-100/90 font-medium">
              <span>儲蓄容量進度</span>
              <span className="font-semibold text-emerald-300">剩餘 85%</span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-black/30 border border-white/[0.08] p-0.5 flex items-center overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#10B981] to-[#34D399] shadow-[0_0_12px_rgba(52,211,153,0.5)] transition-all duration-700"
                style={{ width: '85%' }}
              />
            </div>
          </div>

          {/* Card Footer Metrics */}
          <div className="pt-2 flex items-center justify-between gap-3 bg-black/30 border border-white/[0.08] rounded-xl px-3.5 py-2 backdrop-blur-sm">
            <div className="flex flex-col flex-1 min-w-0">
              <span className="text-[11px] text-emerald-200/70 truncate">已花費 Total Spent</span>
              <span className="text-xs font-bold text-white">
                $750 <span className="text-[10px] font-normal text-emerald-300/70">(15%)</span>
              </span>
            </div>
            <div className="w-px h-6 bg-white/10" />
            <div className="flex flex-col flex-1 min-w-0 text-right">
              <span className="text-[11px] text-emerald-200/70 truncate">預算金庫 Total Budget</span>
              <span className="text-xs font-bold text-white">$5,000</span>
            </div>
          </div>
        </div>
      </section>

      {/* Side-by-Side Stat Cards (2 Columns) */}
      <section className="grid grid-cols-2 gap-3 w-full">
        {/* Left: Spent */}
        <div
          className={`flex flex-col justify-between p-3.5 rounded-2xl ${
            darkMode
              ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
              : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span
              className={`text-xs font-medium ${
                darkMode ? 'text-[#94A3B8]' : 'text-neutral-500'
              }`}
            >
              總花費 Spent
            </span>
            <div className="w-7 h-7 rounded-full bg-[#F87171]/15 border border-[#F87171]/30 flex items-center justify-center text-[#F87171]">
              <span className="material-symbols-outlined text-[16px]">arrow_outward</span>
            </div>
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-xl sm:text-2xl font-bold text-[#F87171] tracking-tight font-mono">
              $750
            </span>
            <span className="text-[10px] text-[#F87171]/80">佔總預算 15%</span>
          </div>
        </div>

        {/* Right: Remaining */}
        <div
          className={`flex flex-col justify-between p-3.5 rounded-2xl ${
            darkMode
              ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
              : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span
              className={`text-xs font-medium ${
                darkMode ? 'text-[#94A3B8]' : 'text-neutral-500'
              }`}
            >
              預算剩餘 Left
            </span>
            <div className="w-7 h-7 rounded-full bg-[#34D399]/15 border border-[#34D399]/30 flex items-center justify-center text-[#34D399]">
              <span className="material-symbols-outlined text-[16px]">account_balance_wallet</span>
            </div>
          </div>
          <div className="flex flex-col gap-0.5">
            <span className="text-xl sm:text-2xl font-bold text-[#34D399] tracking-tight font-mono">
              $4,250
            </span>
            <span className="text-[10px] text-[#34D399]/80">剩餘日均可花 $151</span>
          </div>
        </div>
      </section>

      {/* Category Allocation Donut Chart Card */}
      <section
        className={`flex flex-col p-4 rounded-2xl ${
          darkMode
            ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
        }`}
      >
        <div className="flex items-center justify-between pb-2">
          <div className="flex items-center space-x-1.5">
            <span className="material-symbols-outlined text-[#34D399] text-[20px]">donut_large</span>
            <h2
              className={`text-sm font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              本月預算佔比 Budget Allocation
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('analytics')}
            className="text-xs text-[#34D399] font-semibold hover:underline active:scale-95 transition-transform"
          >
            查看全部
          </button>
        </div>

        {/* Donut Chart with Center Text */}
        <div className="relative flex items-center justify-center my-2">
          <svg
            aria-label="本月預算分佈環狀圖"
            className="w-44 h-44 transform -rotate-90 drop-shadow-[0_0_12px_rgba(52,211,153,0.15)]"
            viewBox="0 0 100 100"
          >
            {/* Background Track */}
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="38"
              stroke={darkMode ? '#242C27' : '#f3f4f5'}
              strokeWidth="12"
            />
            {/* Unused Budget 85% */}
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="38"
              stroke="#34D399"
              strokeDasharray="202.95 238.76"
              strokeDashoffset="0"
              strokeWidth="12"
              className="transition-all duration-700"
            />
            {/* Food 10% */}
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="38"
              stroke="#FB923C"
              strokeDasharray="23.88 238.76"
              strokeDashoffset="-202.95"
              strokeWidth="12"
              className="transition-all duration-700"
            />
            {/* Daily Life 3% */}
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="38"
              stroke="#38BDF8"
              strokeDasharray="7.16 238.76"
              strokeDashoffset="-226.83"
              strokeWidth="12"
              className="transition-all duration-700"
            />
            {/* Commute 2% */}
            <circle
              cx="50"
              cy="50"
              fill="transparent"
              r="38"
              stroke="#FBBF24"
              strokeDasharray="4.78 238.76"
              strokeDashoffset="-233.99"
              strokeWidth="12"
              className="transition-all duration-700"
            />
          </svg>

          <div className="absolute flex flex-col items-center justify-center pointer-events-none text-center">
            <span
              className={`text-[11px] font-medium ${
                darkMode ? 'text-[#94A3B8]' : 'text-neutral-500'
              }`}
            >
              本月預算總額
            </span>
            <span
              className={`text-lg font-bold font-mono leading-tight ${
                darkMode ? 'text-white' : 'text-neutral-900'
              }`}
            >
              $5,000
            </span>
            <span className="text-[10px] text-[#34D399] font-semibold mt-0.5">
              剩餘 85% ($4,250)
            </span>
          </div>
        </div>

        {/* 4 Legend Items */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <div
            className={`flex items-center justify-between p-2 rounded-xl ${
              darkMode ? 'bg-[#212824] border border-white/[0.04]' : 'bg-neutral-50 border border-neutral-100'
            }`}
          >
            <div className="flex items-center space-x-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-[#34D399] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span
                  className={`text-xs font-medium truncate ${
                    darkMode ? 'text-[#F1F5F9]' : 'text-neutral-800'
                  }`}
                >
                  未用預算
                </span>
                <span className="text-[11px] text-[#88938b] font-mono">$4,250</span>
              </div>
            </div>
            <span
              className={`text-xs font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              85%
            </span>
          </div>

          <div
            className={`flex items-center justify-between p-2 rounded-xl ${
              darkMode ? 'bg-[#212824] border border-white/[0.04]' : 'bg-neutral-50 border border-neutral-100'
            }`}
          >
            <div className="flex items-center space-x-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FB923C] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span
                  className={`text-xs font-medium truncate ${
                    darkMode ? 'text-[#F1F5F9]' : 'text-neutral-800'
                  }`}
                >
                  食品餐飲
                </span>
                <span className="text-[11px] text-[#88938b] font-mono">$500</span>
              </div>
            </div>
            <span
              className={`text-xs font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              10%
            </span>
          </div>

          <div
            className={`flex items-center justify-between p-2 rounded-xl ${
              darkMode ? 'bg-[#212824] border border-white/[0.04]' : 'bg-neutral-50 border border-neutral-100'
            }`}
          >
            <div className="flex items-center space-x-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-[#38BDF8] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span
                  className={`text-xs font-medium truncate ${
                    darkMode ? 'text-[#F1F5F9]' : 'text-neutral-800'
                  }`}
                >
                  日常生活
                </span>
                <span className="text-[11px] text-[#88938b] font-mono">$150</span>
              </div>
            </div>
            <span
              className={`text-xs font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              3%
            </span>
          </div>

          <div
            className={`flex items-center justify-between p-2 rounded-xl ${
              darkMode ? 'bg-[#212824] border border-white/[0.04]' : 'bg-neutral-50 border border-neutral-100'
            }`}
          >
            <div className="flex items-center space-x-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FBBF24] shrink-0" />
              <div className="flex flex-col min-w-0">
                <span
                  className={`text-xs font-medium truncate ${
                    darkMode ? 'text-[#F1F5F9]' : 'text-neutral-800'
                  }`}
                >
                  交通通勤
                </span>
                <span className="text-[11px] text-[#88938b] font-mono">$100</span>
              </div>
            </div>
            <span
              className={`text-xs font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              2%
            </span>
          </div>
        </div>
      </section>

      {/* Subscriptions & Fixed Bills Card */}
      <section
        className={`flex flex-col p-4 rounded-2xl ${
          darkMode
            ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
        }`}
      >
        <div className="flex items-center justify-between pb-3">
          <div className="flex items-center space-x-2">
            <span className="material-symbols-outlined text-[#34D399] text-[20px]">sync</span>
            <div>
              <h2
                className={`text-sm font-bold leading-tight ${
                  darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
                }`}
              >
                訂閱與定期扣款
              </h2>
              <span
                className={`text-[11px] ${
                  darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                }`}
              >
                合計約 $520/月
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenAddModal}
            className={`h-7 px-2.5 rounded-full ${
              darkMode
                ? 'bg-[#212824] border border-white/[0.06] text-[#34D399]'
                : 'bg-emerald-50 text-[#346247]'
            } text-xs font-semibold flex items-center space-x-1 active:scale-95 transition-transform`}
          >
            <span className="material-symbols-outlined text-[14px]">add</span>
            <span>新增訂閱</span>
          </button>
        </div>

        {/* Subscriptions List */}
        <div className="flex flex-col gap-2">
          {subscriptions.map((sub) => (
            <div
              key={sub.id}
              className={`flex items-center justify-between p-3 rounded-xl ${
                darkMode
                  ? 'bg-[#212824] border border-white/[0.04]'
                  : 'bg-neutral-50 border border-neutral-100'
              }`}
            >
              <div className="flex items-center space-x-3 min-w-0">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm shrink-0"
                  style={{
                    backgroundColor: `${sub.accentColor}20`,
                    borderColor: `${sub.accentColor}40`,
                    color: sub.accentColor,
                  }}
                >
                  {sub.iconType === 'letter' ? (
                    sub.iconLetter
                  ) : (
                    <span className="material-symbols-outlined text-[19px] fill">
                      {sub.iconName}
                    </span>
                  )}
                </div>
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center space-x-1.5">
                    <span
                      className={`text-xs font-bold truncate ${
                        darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
                      }`}
                    >
                      {sub.name}
                    </span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-semibold ${
                        sub.billingCycle === 'monthly'
                          ? 'bg-purple-900/30 text-purple-300 border border-purple-700/30'
                          : 'bg-blue-900/30 text-blue-300 border border-blue-700/30'
                      }`}
                    >
                      {sub.badgeText}
                    </span>
                  </div>
                  <span
                    className={`text-[11px] truncate ${
                      darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                    }`}
                  >
                    {sub.scheduleDescription}
                  </span>
                </div>
              </div>
              <div className="flex flex-col items-end shrink-0 pl-2">
                <span
                  className={`text-xs font-bold font-mono ${
                    darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
                  }`}
                >
                  ${sub.amount.toLocaleString()}
                </span>
                <span
                  className={`text-[10px] ${
                    darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                  }`}
                >
                  {sub.billingCycle === 'monthly'
                    ? '/月'
                    : `/年 (約 $${sub.monthlyEquivalent}/月)`}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Savings Goals Wishlist Card */}
      <section
        className={`flex flex-col p-4 rounded-2xl ${
          darkMode
            ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
        }`}
      >
        <div className="flex items-center justify-between pb-3">
          <div className="flex items-center space-x-2">
            <span className="material-symbols-outlined text-[#E9C46A] text-[20px] fill">
              savings
            </span>
            <h2
              className={`text-sm font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              夢想儲蓄目標箱
            </h2>
          </div>
          <button
            type="button"
            onClick={onOpenAddModal}
            className={`h-7 px-2.5 rounded-full ${
              darkMode
                ? 'bg-[#212824] border border-white/[0.06] text-[#34D399]'
                : 'bg-emerald-50 text-[#346247]'
            } text-xs font-semibold flex items-center space-x-1 active:scale-95 transition-transform`}
          >
            <span className="material-symbols-outlined text-[14px]">add</span>
            <span>新增目標</span>
          </button>
        </div>

        {/* Goal Item Box */}
        {savingsGoals.map((goal) => (
          <div
            key={goal.id}
            className={`p-3.5 rounded-xl ${
              darkMode
                ? 'bg-gradient-to-br from-[#1E2521] via-[#1A201C] to-[#171C19] border border-white/[0.05]'
                : 'bg-neutral-50 border border-neutral-200/80'
            } flex flex-col gap-2.5`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2.5">
                <div
                  className={`w-10 h-10 rounded-2xl ${
                    darkMode ? 'bg-[#2A372E] text-[#34D399]' : 'bg-emerald-100 text-[#346247]'
                  } flex items-center justify-center shrink-0 shadow-sm`}
                >
                  <span className="material-symbols-outlined text-[20px]">flight_takeoff</span>
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center space-x-1.5">
                    <span
                      className={`text-xs font-bold ${
                        darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
                      }`}
                    >
                      {goal.title}
                    </span>
                    <span className="text-sm">{goal.emoji}</span>
                  </div>
                  <span
                    className={`text-[11px] ${
                      darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                    }`}
                  >
                    預計 {goal.targetDate} 達成
                  </span>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-xs font-bold text-[#34D399] font-mono">
                  ${goal.currentAmount.toLocaleString()}
                </span>
                <span
                  className={`text-[10px] ${
                    darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                  }`}
                >
                  目標 ${goal.targetAmount.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Target Progress */}
            <div className="flex flex-col gap-1">
              <div
                className={`flex justify-between text-[11px] ${
                  darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                }`}
              >
                <span>進度進展</span>
                <span className="font-bold text-[#34D399]">{goal.progressPercent}%</span>
              </div>
              <div
                className={`w-full h-2 rounded-full ${
                  darkMode ? 'bg-[#141916]' : 'bg-neutral-200'
                } overflow-hidden`}
              >
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#2DD4BF] to-[#34D399] shadow-[0_0_8px_rgba(45,212,191,0.4)] transition-all duration-700"
                  style={{ width: `${goal.progressPercent}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Itemized Transactions List ("記帳細項紀錄") */}
      <section className="flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center space-x-1.5">
            <span className="material-symbols-outlined text-[#34D399] text-[20px]">receipt_long</span>
            <h2
              className={`text-sm font-bold ${
                darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
              }`}
            >
              記帳細項紀錄
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('transactions')}
            className="text-xs font-semibold text-[#34D399] flex items-center space-x-0.5 hover:underline active:scale-95 transition-transform"
          >
            <span>檢視明細</span>
            <span className="material-symbols-outlined text-[15px]">chevron_right</span>
          </button>
        </div>

        {/* Date Sub-header Banner */}
        <div
          className={`flex items-center justify-between px-3 py-1.5 rounded-lg ${
            darkMode
              ? 'bg-[#191E1B] border border-white/[0.04] text-[#88938b]'
              : 'bg-neutral-100 border border-neutral-200 text-neutral-600'
          } text-[11px]`}
        >
          <div className="flex items-center space-x-1.5">
            <span className="material-symbols-outlined text-[14px]">event</span>
            <span
              className={`font-semibold ${
                darkMode ? 'text-[#E2E8F0]' : 'text-neutral-800'
              }`}
            >
              今日 09月09日
            </span>
          </div>
          <span className="font-semibold text-[#FB7185]">當天小計: -$185</span>
        </div>

        {/* Transactions Group Container */}
        <div
          className={`flex flex-col p-2 rounded-2xl ${
            darkMode
              ? 'bg-[#191E1B] border border-white/[0.06] shadow-[0_4px_16px_rgba(0,0,0,0.35)] divide-y divide-white/[0.05]'
              : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)] divide-y divide-neutral-100'
          }`}
        >
          {recentTransactions.map((tx) => {
            const isExpense = tx.type === 'expense';
            return (
              <div
                key={tx.id}
                className="flex items-center justify-between py-2.5 px-2 hover:bg-white/[0.02] transition cursor-pointer group"
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform"
                    style={{
                      backgroundColor: tx.categoryBg,
                      color: tx.categoryColor,
                    }}
                  >
                    <span
                      className="material-symbols-outlined text-[20px]"
                      style={{
                        fontVariationSettings: tx.type === 'income' ? "'FILL' 1" : "'FILL' 0",
                      }}
                    >
                      {tx.categoryIcon}
                    </span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <span
                        className={`text-xs font-bold truncate ${
                          darkMode ? 'text-[#F1F5F9]' : 'text-neutral-900'
                        }`}
                      >
                        {tx.category}
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                          darkMode
                            ? 'bg-[#242C27] text-[#88938b] border border-white/[0.04]'
                            : 'bg-neutral-100 text-neutral-600 border border-neutral-200'
                        }`}
                      >
                        {tx.account.split(' ')[0]}
                      </span>
                    </div>
                    <span
                      className={`text-[11px] truncate ${
                        darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                      }`}
                    >
                      {tx.title}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0 pl-2">
                  <span
                    className={`text-xs font-bold font-mono tracking-tight ${
                      isExpense ? 'text-[#FB7185]' : 'text-[#34D399]'
                    }`}
                  >
                    {isExpense ? `-$${tx.amount.toLocaleString()}` : `+$${tx.amount.toLocaleString()}`}
                  </span>
                  <span
                    className={`text-[10px] ${
                      darkMode ? 'text-[#88938b]' : 'text-neutral-400'
                    }`}
                  >
                    {tx.time}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
