import React from 'react';

interface StatusBarProps {
  darkMode: boolean;
}

export const StatusBar: React.FC<StatusBarProps> = ({ darkMode }) => {
  return (
    <div
      id="android-status-bar"
      className={`pt-3 px-6 pb-2 flex justify-between items-center text-xs font-semibold ${
        darkMode ? 'text-[#88938b]' : 'text-neutral-600'
      } bg-transparent select-none`}
    >
      <span className="font-medium">09:41</span>
      <div className="flex items-center space-x-1.5">
        <span className="material-symbols-outlined text-[15px]">signal_cellular_4_bar</span>
        <span className="material-symbols-outlined text-[15px]">wifi</span>
        <span className="material-symbols-outlined text-[15px]">battery_full</span>
      </div>
    </div>
  );
};
