import React, { useState } from 'react';

interface AndroidKotlinModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
}

export const AndroidKotlinModal: React.FC<AndroidKotlinModalProps> = ({
  isOpen,
  onClose,
  darkMode,
}) => {
  if (!isOpen) return null;

  const [selectedFile, setSelectedFile] = useState<string>('MainActivity.kt');
  const [copied, setCopied] = useState<boolean>(false);

  const kotlinFiles: { [key: string]: string } = {
    'MainActivity.kt': `package com.example.budgetmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.example.budgetmanager.ui.theme.BudgetManagerTheme
import com.example.budgetmanager.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var isDarkTheme by remember { mutableStateOf(true) }
            BudgetManagerTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BudgetManagerApp(
                        isDarkTheme = isDarkTheme,
                        onToggleTheme = { isDarkTheme = !isDarkTheme }
                    )
                }
            }
        }
    }
}

@Composable
fun BudgetManagerApp(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            BudgetBottomNavigation(navController = navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { /* 記一筆快速記帳 */ },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "記一筆")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("記一筆", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("dashboard") { DashboardScreen(onNavigate = { navController.navigate(it) }) }
            composable("transactions") { TransactionsScreen() }
            composable("analytics") { AnalyticsScreen() }
            composable("settings") { 
                SettingsScreen(
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = onToggleTheme
                ) 
            }
        }
    }
}`,

    'Theme.kt': `package com.example.budgetmanager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Budget Manager Emerald Forest Palette
val ForestPrimary = Color(0xFF34D399)
val ForestOnPrimary = Color(0xFF003825)
val ForestPrimaryContainer = Color(0xFF1B4A31)
val ForestBackground = Color(0xFF101412)
val ForestSurface = Color(0xFF161C18)
val ForestSurfaceVariant = Color(0xFF1E2621)
val ExpenseCoral = Color(0xFFFB7185)
val IncomeTeal = Color(0xFF34D399)
val AmberAccent = Color(0xFFFBBF24)

private val DarkColorScheme = darkColorScheme(
    primary = ForestPrimary,
    onPrimary = ForestOnPrimary,
    primaryContainer = ForestPrimaryContainer,
    background = ForestBackground,
    surface = ForestSurface,
    surfaceVariant = ForestSurfaceVariant,
    error = ExpenseCoral,
    tertiary = AmberAccent
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF346247),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7F0E0),
    background = Color(0xFFF8F9FA),
    surface = Color.White,
    surfaceVariant = Color(0xFFF3F4F5),
    error = Color(0xFFE76F51),
    tertiary = Color(0xFFE9C46A)
)

@Composable
fun BudgetManagerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}`,

    'DashboardScreen.kt': `package com.example.budgetmanager.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Savings Card
        Card(
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF1A3E2C), Color(0xFF0E2419))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "預估本月儲蓄 Estimated Savings",
                        color = Color(0xFF34D399),
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "$4,250 TWD",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("儲蓄容量進度", color = Color(0xFFB1E1C4), fontSize = 12.sp)
                        Text("剩餘 85%", color = Color(0xFF34D399), fontSize = 12.sp)
                    }
                    LinearProgressIndicator(
                        progress = 0.85f,
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = Color(0xFF34D399),
                        trackColor = Color(0xFF132A1E)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("已花費 Total Spent", color = Color.Gray, fontSize = 11.sp)
                            Text("$750 (15%)", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("預算金庫 Total Budget", color = Color.Gray, fontSize = 11.sp)
                            Text("$5,000", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Spent & Remaining 2-column cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF191E1B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("總花費 Spent", color = Color.Gray, fontSize = 12.sp)
                    Text("$750", color = Color(0xFFF87171), fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF191E1B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("預算剩餘 Left", color = Color.Gray, fontSize = 12.sp)
                    Text("$4,250", color = Color(0xFF34D399), fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                }
            }
        }
        
        // 3. Subscriptions Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF191E1B))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("訂閱與定期扣款", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                SubscriptionRow("Netflix", "每月 15 日自動扣款", "$270 /月")
                SubscriptionRow("iCloud+ 2TB", "每年 9 月 15 日", "$3,000 /年")
            }
        }
    }
}

@Composable
fun SubscriptionRow(title: String, desc: String, cost: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Text(desc, color = Color.Gray, fontSize = 11.sp)
        }
        Text(cost, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}`,

    'SettingsScreen.kt': `package com.example.budgetmanager.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "預算與金庫設定",
            color = Color.Gray,
            style = MaterialTheme.typography.labelMedium
        )
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                SettingRow(title = "本月目標小金庫", desc = "自動扣除計算剩餘可支配生活費", value = "$8,000 TWD")
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.White.copy(alpha = 0.05f))
                SettingToggleRow(title = "動態生活費預算池", desc = "累積過去天數未花完預算至次日", initialChecked = true)
            }
        }

        Text(
            text = "個人化外觀與語言",
            color = Color.Gray,
            style = MaterialTheme.typography.labelMedium
        )
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                SettingRow(title = "色彩主題", desc = "目前使用：翡翠綠主題", value = "翡翠綠")
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.White.copy(alpha = 0.05f))
                SettingRow(title = "系統語言", desc = "預設顯示語系設定", value = "繁體中文 (台灣)")
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.White.copy(alpha = 0.05f))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("深色外觀模式", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                        Text("切換至高對比夜間暗色森林主題", color = Color.Gray, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isDarkTheme,
                        onCheckedChange = { onToggleTheme() },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                    )
                }
            }
        }
    }
}

@Composable
fun SettingRow(title: String, desc: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Text(desc, color = Color.Gray, fontSize = 11.sp)
        }
        Text(value, color = Color(0xFF34D399), fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}

@Composable
fun SettingToggleRow(title: String, desc: String, initialChecked: Boolean) {
    var checked by remember { mutableStateOf(initialChecked) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Text(desc, color = Color.Gray, fontSize = 11.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = { checked = it },
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
        )
    }
}`,

    'build.gradle.kts': `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.budgetmanager"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.budgetmanager"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.2"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.compose.material:material-icons-extended:1.7.6")
}`
  };

  const handleCopyCode = () => {
    const code = kotlinFiles[selectedFile];
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-3 sm:p-6 animate-fade-in">
      <div
        className={`w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl ${
          darkMode ? 'bg-[#121614] text-[#e0e3df] border border-[#34d399]/30' : 'bg-white text-neutral-900 border border-neutral-300'
        } shadow-2xl overflow-hidden`}
      >
        {/* Modal Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#34d399]/20 text-[#34d399] flex items-center justify-center font-bold">
              <span className="material-symbols-outlined text-[20px]">android</span>
            </div>
            <div>
              <h3 className="text-base font-bold flex items-center gap-1.5">
                Android Studio (Kotlin + Jetpack Compose) 專案原始碼
              </h3>
              <p className="text-xs text-[#88938b]">
                直接複製到 Android Studio 中運行，完整對應此應用程式的 4 個畫面與主題架構
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#88938b] hover:bg-white/10 transition"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center space-x-1 p-2 px-4 bg-black/20 border-b border-white/5 overflow-x-auto no-scrollbar">
          {Object.keys(kotlinFiles).map((fileName) => (
            <button
              key={fileName}
              type="button"
              onClick={() => setSelectedFile(fileName)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium whitespace-nowrap transition-all ${
                selectedFile === fileName
                  ? 'bg-[#34d399] text-[#003825] font-bold shadow-sm'
                  : 'text-[#88938b] hover:text-white hover:bg-white/5'
              }`}
            >
              {fileName}
            </button>
          ))}
        </div>

        {/* Code Viewer */}
        <div className="flex-1 p-4 overflow-y-auto no-scrollbar bg-[#0b0e0c] font-mono text-xs text-[#bbf7d0] leading-relaxed select-text">
          <pre className="whitespace-pre overflow-x-auto">{kotlinFiles[selectedFile]}</pre>
        </div>

        {/* Modal Footer */}
        <div className="p-3 px-4 border-t border-white/10 flex items-center justify-between bg-[#121614]">
          <div className="text-xs text-[#88938b] flex items-center space-x-1">
            <span className="material-symbols-outlined text-[15px] text-[#34d399]">check_circle</span>
            <span>支援 Android Studio Ladybug / Koala (Kotlin 2.0+ / Compose Material 3)</span>
          </div>
          <button
            type="button"
            onClick={handleCopyCode}
            className="px-4 py-2 rounded-xl bg-[#10b981] hover:bg-[#059669] text-[#002111] font-bold text-xs flex items-center space-x-1.5 shadow active:scale-95 transition"
          >
            <span className="material-symbols-outlined text-[16px]">
              {copied ? 'done' : 'content_copy'}
            </span>
            <span>{copied ? '已複製到剪貼簿！' : `複製 ${selectedFile}`}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
