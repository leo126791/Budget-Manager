import React, { useState } from 'react';
import { Transaction, TransactionType } from '../types';
import { availableAccounts, availableCategories } from '../data/initialData';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, 'id'>) => void;
  darkMode: boolean;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  darkMode,
}) => {
  if (!isOpen) return null;

  const [type, setType] = useState<TransactionType>('expense');
  const [amountStr, setAmountStr] = useState<string>('0');
  const [selectedCategory, setSelectedCategory] = useState<string>('食品餐飲');
  const [selectedAccount, setSelectedAccount] = useState<string>('信用卡 (國泰世華)');
  const [title, setTitle] = useState<string>('');
  const [tag, setTag] = useState<string>('');

  const handleKeypadPress = (val: string) => {
    if (val === 'C') {
      setAmountStr('0');
      return;
    }
    if (val === 'backspace') {
      if (amountStr.length <= 1) {
        setAmountStr('0');
      } else {
        setAmountStr(amountStr.slice(0, -1));
      }
      return;
    }
    if (val === '.') {
      if (!amountStr.includes('.')) {
        setAmountStr(amountStr + '.');
      }
      return;
    }
    // Digits
    if (amountStr === '0') {
      setAmountStr(val);
    } else {
      if (amountStr.length < 9) {
        setAmountStr(amountStr + val);
      }
    }
  };

  const handleSave = () => {
    const num = parseFloat(amountStr);
    if (isNaN(num) || num <= 0) {
      alert('請輸入有效金額！');
      return;
    }

    const catObj = availableCategories.find((c) => c.name === selectedCategory) || {
      name: selectedCategory,
      icon: 'receipt_long',
      color: '#34d399',
    };

    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const timeStr = `${hours}:${minutes}`;

    onSave({
      title: title.trim() || `${catObj.name} 消費`,
      amount: num,
      type,
      category: catObj.name,
      categoryIcon: catObj.icon,
      categoryBg: `${catObj.color}25`,
      categoryColor: catObj.color,
      account: selectedAccount,
      date: now.toISOString().slice(0, 10),
      dateDisplay: '今日 · 09月09日 星期三',
      time: timeStr,
      tag: tag.trim() || undefined,
      note: '手動記帳',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
      <div
        className={`w-full max-w-md ${
          darkMode ? 'bg-[#141815] text-[#e0e3df]' : 'bg-white text-neutral-900'
        } rounded-t-3xl sm:rounded-3xl shadow-2xl border ${
          darkMode ? 'border-white/10' : 'border-neutral-200'
        } overflow-hidden max-h-[92vh] flex flex-col`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 pb-2 border-b border-white/5">
          <div className="flex items-center space-x-2">
            <span className="material-symbols-outlined text-[#34d399] text-[22px]">edit_note</span>
            <h3 className="text-base font-bold">快速記一筆</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#88938b] hover:bg-white/10 transition"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto no-scrollbar p-4 space-y-4">
          {/* Segment: Expense / Income */}
          <div
            className={`flex p-1 rounded-full ${
              darkMode ? 'bg-[#1c221e]' : 'bg-neutral-100'
            }`}
          >
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`flex-1 py-1.5 rounded-full text-xs font-bold transition-all ${
                type === 'expense'
                  ? 'bg-[#fb7185] text-white shadow'
                  : 'text-[#88938b] hover:text-white'
              }`}
            >
              支出
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`flex-1 py-1.5 rounded-full text-xs font-bold transition-all ${
                type === 'income'
                  ? 'bg-[#34d399] text-[#002111] shadow'
                  : 'text-[#88938b] hover:text-white'
              }`}
            >
              收入
            </button>
          </div>

          {/* Amount Display */}
          <div
            className={`p-4 rounded-2xl ${
              darkMode ? 'bg-[#1a221d] border border-white/5' : 'bg-neutral-50 border border-neutral-200'
            } text-center`}
          >
            <span className="text-xs text-[#88938b]">輸入金額 (TWD)</span>
            <div className="flex items-center justify-center space-x-1 mt-1">
              <span
                className={`text-2xl font-bold ${
                  type === 'expense' ? 'text-[#fb7185]' : 'text-[#34d399]'
                }`}
              >
                {type === 'expense' ? '-$' : '+$'}
              </span>
              <span className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight">
                {amountStr}
              </span>
            </div>
          </div>

          {/* Category Selector */}
          <div>
            <label className="text-xs font-semibold text-[#88938b] px-1 mb-2 block">
              選擇分類
            </label>
            <div className="grid grid-cols-4 gap-2">
              {availableCategories.map((cat) => {
                const isSelected = selectedCategory === cat.name;
                return (
                  <button
                    key={cat.name}
                    type="button"
                    onClick={() => setSelectedCategory(cat.name)}
                    className={`flex flex-col items-center p-2 rounded-xl border transition-all ${
                      isSelected
                        ? darkMode
                          ? 'bg-[#1e2e24] border-[#34d399] text-[#34d399]'
                          : 'bg-emerald-50 border-[#346247] text-[#346247]'
                        : darkMode
                        ? 'bg-[#1a201c] border-white/5 text-[#88938b] hover:border-white/20'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                    }`}
                  >
                    <span
                      className="material-symbols-outlined text-[20px]"
                      style={{ color: cat.color }}
                    >
                      {cat.icon}
                    </span>
                    <span className="text-[11px] font-medium mt-1 truncate max-w-full">
                      {cat.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title & Account */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-[#88938b] px-1 mb-1 block">
                備註名稱
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="例如：午餐便當"
                className={`w-full p-2.5 rounded-xl text-xs ${
                  darkMode
                    ? 'bg-[#1a201c] border border-white/5 text-white'
                    : 'bg-neutral-50 border border-neutral-200 text-neutral-900'
                } focus:outline-none focus:ring-1 focus:ring-[#34d399]`}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-[#88938b] px-1 mb-1 block">
                支付帳戶
              </label>
              <select
                value={selectedAccount}
                onChange={(e) => setSelectedAccount(e.target.value)}
                className={`w-full p-2.5 rounded-xl text-xs ${
                  darkMode
                    ? 'bg-[#1a201c] border border-white/5 text-white'
                    : 'bg-neutral-50 border border-neutral-200 text-neutral-900'
                } focus:outline-none focus:ring-1 focus:ring-[#34d399]`}
              >
                {availableAccounts.map((acc) => (
                  <option key={acc} value={acc}>
                    {acc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Numeric Calculator Keypad */}
          <div className="grid grid-cols-4 gap-1.5 pt-1">
            {['1', '2', '3', '⌫', '4', '5', '6', 'C', '7', '8', '9', '.', '0', '00'].map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => {
                  if (k === '⌫') handleKeypadPress('backspace');
                  else handleKeypadPress(k);
                }}
                className={`py-3 rounded-xl text-sm font-bold font-mono active:scale-95 transition ${
                  k === '⌫' || k === 'C'
                    ? darkMode
                      ? 'bg-[#28332a] text-[#fb7185]'
                      : 'bg-neutral-200 text-neutral-700'
                    : darkMode
                    ? 'bg-[#1a201c] text-white hover:bg-[#222b25]'
                    : 'bg-neutral-100 text-neutral-900 hover:bg-neutral-200'
                }`}
              >
                {k}
              </button>
            ))}
            <button
              type="button"
              onClick={handleSave}
              className="col-span-2 py-3 rounded-xl bg-[#10b981] hover:bg-[#059669] text-[#002111] font-bold text-sm shadow-md active:scale-95 transition"
            >
              儲存完成
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
