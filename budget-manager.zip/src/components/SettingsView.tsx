import React from 'react';
import { AppSettings } from '../types';

interface SettingsViewProps {
  darkMode: boolean;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  onExportCsv: () => void;
  onOpenKotlinModal: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  darkMode,
  settings,
  onUpdateSettings,
  onExportCsv,
  onOpenKotlinModal,
}) => {
  const toggleBetaFeature = (key: keyof AppSettings['betaFeatures']) => {
    onUpdateSettings({
      betaFeatures: {
        ...settings.betaFeatures,
        [key]: !settings.betaFeatures[key],
      },
    });
  };

  return (
    <div className="flex flex-col w-full gap-4 pb-12">
      {/* Group 1: 預算與金庫設定 (Budget & Vault) */}
      <div className="space-y-1.5">
        <h3
          className={`text-xs font-bold uppercase tracking-wider px-2 ${
            darkMode ? 'text-[#88938b]' : 'text-neutral-500'
          }`}
        >
          預算與金庫設定
        </h3>
        <div
          className={`rounded-2xl shadow-sm border divide-y overflow-hidden ${
            darkMode
              ? 'bg-[#161c18] border-white/5 divide-white/5'
              : 'bg-white border-neutral-200/80 divide-neutral-100'
          }`}
        >
          {/* 本月目標小金庫 */}
          <div
            onClick={() => {
              const newAmount = prompt('請輸入本月目標小金庫預算金額 (TWD):', String(settings.vaultBudget));
              if (newAmount && !isNaN(Number(newAmount))) {
                onUpdateSettings({ vaultBudget: Number(newAmount) });
              }
            }}
            className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition cursor-pointer"
          >
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  darkMode ? 'bg-emerald-500/15 text-[#34d399]' : 'bg-emerald-50 text-[#346247]'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">savings</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  本月目標小金庫
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  自動扣除計算剩餘可支配生活費
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <span
                className={`text-xs font-semibold px-2.5 py-0.5 rounded-md font-mono ${
                  darkMode
                    ? 'text-[#34d399] bg-[#34d399]/10 border border-[#34d399]/20'
                    : 'text-[#346247] bg-emerald-50/80'
                }`}
              >
                ${settings.vaultBudget.toLocaleString()} TWD
              </span>
              <span className="material-symbols-outlined text-[18px] text-[#6b776f]">
                chevron_right
              </span>
            </div>
          </div>

          {/* 動態生活費預算池 */}
          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  darkMode ? 'bg-teal-500/15 text-[#34d399]' : 'bg-teal-50 text-teal-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  動態生活費預算池
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  累積過去天數未花完預算至次日
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ dynamicBudgetPool: !settings.dynamicBudgetPool })}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 shadow-inner ${
                settings.dynamicBudgetPool
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028]' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
                  settings.dynamicBudgetPool ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Group 2: 個人化外觀與語言 (Appearance & Themes) */}
      <div className="space-y-1.5">
        <h3
          className={`text-xs font-bold uppercase tracking-wider px-2 ${
            darkMode ? 'text-[#88938b]' : 'text-neutral-500'
          }`}
        >
          個人化外觀與語言
        </h3>
        <div
          className={`rounded-2xl shadow-sm border divide-y overflow-hidden ${
            darkMode
              ? 'bg-[#161c18] border-white/5 divide-white/5'
              : 'bg-white border-neutral-200/80 divide-neutral-100'
          }`}
        >
          {/* 色彩主題 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition cursor-pointer">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  darkMode ? 'bg-purple-500/15 text-purple-400' : 'bg-purple-50 text-purple-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">palette</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  色彩主題
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  目前使用：翡翠綠主題
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-1.5 text-[#6b776f]">
              <span
                className={`flex items-center space-x-1 text-xs font-medium px-2 py-0.5 rounded-md ${
                  darkMode
                    ? 'text-[#34d399] bg-[#34d399]/10 border border-[#34d399]/20'
                    : 'text-neutral-700 bg-neutral-100'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-[#34d399]" />
                <span>翡翠綠</span>
              </span>
              <span className="material-symbols-outlined text-[18px]">chevron_right</span>
            </div>
          </div>

          {/* 系統語言 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition cursor-pointer">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  darkMode ? 'bg-blue-500/15 text-blue-400' : 'bg-blue-50 text-blue-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">language</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  系統語言
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  預設顯示語系設定
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-1 text-[#6b776f]">
              <span
                className={`text-xs font-medium ${
                  darkMode ? 'text-[#e0e3df]' : 'text-neutral-700'
                }`}
              >
                {settings.language}
              </span>
              <span className="material-symbols-outlined text-[18px]">chevron_right</span>
            </div>
          </div>

          {/* 深色外觀模式 (Switched to ON in dark mode) */}
          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  darkMode ? 'bg-emerald-500/15 text-[#34d399]' : 'bg-neutral-100 text-neutral-700'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">dark_mode</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  深色外觀模式
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  切換至高對比夜間暗色森林主題
                </p>
              </div>
            </div>
            <button
              id="theme-dark-mode-toggle"
              type="button"
              onClick={() => onUpdateSettings({ darkMode: !darkMode })}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 shadow-inner ${
                darkMode ? 'bg-[#10b981]' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
                  darkMode ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Group 3: Beta 實驗性功能 (Beta Lab) */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-2">
          <h3
            className={`text-xs font-bold uppercase tracking-wider ${
              darkMode ? 'text-[#88938b]' : 'text-neutral-500'
            }`}
          >
            Beta 實驗性功能
          </h3>
          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
              darkMode
                ? 'bg-[#34d399]/15 text-[#34d399] border border-[#34d399]/30'
                : 'bg-emerald-100 text-[#346247]'
            }`}
          >
            實驗性實驗室
          </span>
        </div>

        <div
          className={`rounded-2xl shadow-sm border divide-y overflow-hidden ${
            darkMode
              ? 'bg-[#161c18] border-white/5 divide-white/5'
              : 'bg-white border-neutral-200/80 divide-neutral-100'
          }`}
        >
          {/* Master Info Header Item */}
          <div
            className={`p-3.5 flex items-center justify-between ${
              darkMode ? 'bg-[#1f2922]/50' : 'bg-emerald-50/40'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode
                    ? 'bg-[#34d399]/20 text-[#34d399] border border-[#34d399]/30'
                    : 'bg-emerald-100 text-[#346247]'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">science</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-bold flex items-center gap-1.5 ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-900'
                  }`}
                >
                  加入 Beta 實驗性測試
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      darkMode
                        ? 'bg-[#1b4a31] text-[#34d399] border border-[#34d399]/30'
                        : 'bg-[#346247] text-white'
                    }`}
                  >
                    BETA
                  </span>
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  搶先體驗未正式發佈的實驗性自訂功能
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ betaTesting: !settings.betaTesting })}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 shadow-inner ${
                settings.betaTesting
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028]' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
                  settings.betaTesting ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 1: 收入記帳與收支概覽 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-emerald-500/15 text-[#34d399]' : 'bg-emerald-50 text-emerald-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">account_balance</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  收入記帳與收支概覽
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  記錄薪水/獎金與月度收支平衡
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('incomeTracking')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.incomeTracking
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.incomeTracking
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 2: 關鍵字搜尋 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-blue-500/15 text-blue-400' : 'bg-blue-50 text-blue-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">search</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  關鍵字搜尋
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  快速搜尋開銷備註與自訂類別
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('keywordSearch')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.keywordSearch
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.keywordSearch
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 3: 訂閱與定期扣款 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-amber-500/15 text-amber-400' : 'bg-amber-50 text-amber-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">event_repeat</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  訂閱與定期扣款
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  固定支出與定期扣款週期提醒
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('subscriptions')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.subscriptions
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.subscriptions
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 4: 支付方式分類 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-teal-500/15 text-teal-400' : 'bg-teal-50 text-teal-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">credit_card</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  支付方式分類
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  細分現金、信用卡、行動支付帳戶
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('paymentMethods')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.paymentMethods
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.paymentMethods
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 5: 儲蓄目標進度 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-orange-500/15 text-orange-400' : 'bg-orange-50 text-orange-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">flag</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  儲蓄目標進度
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  設定夢想旅遊與購物存錢進度條
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('savingsGoals')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.savingsGoals
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.savingsGoals
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Feature 6: 長按移動紀錄 */}
          <div className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-purple-500/15 text-purple-400' : 'bg-purple-50 text-purple-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">touch_app</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  長按移動紀錄 (不建議開啟)
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  長按記帳紀錄快速將開銷移至其他日期
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => toggleBetaFeature('dragMoveRecords')}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 ${
                settings.betaFeatures.dragMoveRecords
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028] border border-white/5' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full shadow-md transform transition-transform ${
                  settings.betaFeatures.dragMoveRecords
                    ? 'bg-white translate-x-6'
                    : darkMode ? 'bg-[#88938b] translate-x-0.5' : 'bg-white translate-x-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Group 4: 雲端同步與資料管理 (Sync & Data) */}
      <div className="space-y-1.5">
        <h3
          className={`text-xs font-bold uppercase tracking-wider px-2 ${
            darkMode ? 'text-[#88938b]' : 'text-neutral-500'
          }`}
        >
          雲端同步與資料管理
        </h3>
        <div
          className={`rounded-2xl shadow-sm border divide-y overflow-hidden ${
            darkMode
              ? 'bg-[#161c18] border-white/5 divide-white/5'
              : 'bg-white border-neutral-200/80 divide-neutral-100'
          }`}
        >
          {/* 自動雲端備份 */}
          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-emerald-500/15 text-[#34d399]' : 'bg-emerald-50 text-[#346247]'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">sync</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  自動雲端備份
                </p>
                <p
                  className={`text-[11px] font-mono ${
                    darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                  }`}
                >
                  上次備份：{settings.lastBackupTime}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ autoCloudBackup: !settings.autoCloudBackup })}
              className={`w-12 h-6 rounded-full relative p-0.5 transition-colors focus:outline-none flex items-center shrink-0 shadow-inner ${
                settings.autoCloudBackup
                  ? darkMode ? 'bg-[#10b981]' : 'bg-[#346247]'
                  : darkMode ? 'bg-[#253028]' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
                  settings.autoCloudBackup ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          {/* Google Drive 備份與還原 */}
          <div className="p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    darkMode ? 'bg-blue-500/15 text-blue-400' : 'bg-blue-50 text-blue-600'
                  }`}
                >
                  <span className="material-symbols-outlined text-[20px]">cloud_sync</span>
                </div>
                <div>
                  <p
                    className={`text-[14px] font-semibold ${
                      darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                    }`}
                  >
                    Google Drive 備份與還原
                  </p>
                  <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                    安全同步記帳資料與預算至雲端
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-0.5">
              <button
                type="button"
                onClick={() => {
                  alert('已成功建立本地加密雲端備份檔！');
                  onUpdateSettings({ lastBackupTime: new Date().toISOString().replace('T', ' ').slice(0, 16) });
                }}
                className={`flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl font-semibold text-xs border active:scale-95 transition ${
                  darkMode
                    ? 'bg-[#1e2621] hover:bg-[#253029] text-[#e0e3df] border-white/5'
                    : 'bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 border-neutral-200/80'
                }`}
              >
                <span className="material-symbols-outlined text-[17px] text-[#34d399]">
                  cloud_upload
                </span>
                <span>備份至 Drive</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  alert('已成功檢查雲端，資料已是最新版本！');
                }}
                className={`flex items-center justify-center space-x-1.5 py-2 px-3 rounded-xl font-semibold text-xs border active:scale-95 transition ${
                  darkMode
                    ? 'bg-[#1e2621] hover:bg-[#253029] text-[#e0e3df] border-white/5'
                    : 'bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 border-neutral-200/80'
                }`}
              >
                <span className="material-symbols-outlined text-[17px] text-blue-400">
                  cloud_download
                </span>
                <span>還原雲端備份</span>
              </button>
            </div>
          </div>

          {/* 財務報表匯出 (CSV Export) */}
          <div
            onClick={onExportCsv}
            className="p-3.5 flex items-center justify-between hover:bg-white/[0.02] transition cursor-pointer"
          >
            <div className="flex items-center space-x-3">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  darkMode ? 'bg-sky-500/15 text-sky-400' : 'bg-sky-50 text-sky-600'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">file_download</span>
              </div>
              <div>
                <p
                  className={`text-[14px] font-semibold ${
                    darkMode ? 'text-[#f1f5f9]' : 'text-neutral-800'
                  }`}
                >
                  匯出 CSV 財務報表
                </p>
                <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
                  匯出為 Excel / Numbers 試算表格式
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onExportCsv();
              }}
              className={`px-3 py-1 rounded-lg font-semibold text-xs border active:scale-95 transition ${
                darkMode
                  ? 'bg-[#1e2621] hover:bg-[#253029] border-white/10 text-[#34d399]'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-white'
              }`}
            >
              匯出
            </button>
          </div>
        </div>
      </div>

      {/* Android Studio & Kotlin Jetpack Compose Feature Card */}
      <div
        className={`p-3.5 rounded-2xl border ${
          darkMode
            ? 'bg-gradient-to-br from-[#1c2921] to-[#121a15] border-[#34d399]/30 text-white'
            : 'bg-emerald-50 border-emerald-200 text-neutral-900'
        } flex items-center justify-between shadow-sm`}
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-[#34d399]/20 text-[#34d399] flex items-center justify-center font-bold">
            <span className="material-symbols-outlined text-[22px]">developer_mode</span>
          </div>
          <div>
            <p className="text-sm font-bold flex items-center gap-1.5">
              Android Studio 專案導出
              <span className="text-[10px] bg-[#34d399] text-[#002111] font-bold px-1.5 py-0.2 rounded">
                Kotlin
              </span>
            </p>
            <p className={`text-[11px] ${darkMode ? 'text-[#88938b]' : 'text-neutral-600'}`}>
              已備妥完整的 Jetpack Compose 原始碼供 Android 開啟
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onOpenKotlinModal}
          className="px-3 py-1.5 rounded-xl bg-[#10b981] hover:bg-[#059669] text-[#002111] font-bold text-xs shadow active:scale-95 transition"
        >
          查看代碼
        </button>
      </div>

      {/* Version & Footer Info */}
      <div className="pt-2 pb-1 text-center">
        <p className={`text-xs font-bold ${darkMode ? 'text-[#88938b]' : 'text-neutral-500'}`}>
          Budget Manager v1.0.2
        </p>
        <p className={`text-[11px] mt-0.5 ${darkMode ? 'text-[#6d7770]' : 'text-neutral-400'}`}>
          版本 1.0.2・記帳與預算管家
        </p>
      </div>
    </div>
  );
};
