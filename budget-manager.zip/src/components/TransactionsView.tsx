import React, { useState, useMemo } from 'react';
import { Transaction } from '../types';

interface TransactionsViewProps {
  darkMode: boolean;
  transactions: Transaction[];
  searchQuery: string;
  onOpenAddModal: () => void;
  onDeleteTransaction?: (id: string) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  darkMode,
  transactions,
  searchQuery,
  onOpenAddModal,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'expense' | 'income' | 'food' | 'transport' | 'bills'>('all');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = tx.title.toLowerCase().includes(query);
        const matchesCategory = tx.category.toLowerCase().includes(query);
        const matchesAccount = tx.account.toLowerCase().includes(query);
        const matchesTag = tx.tag?.toLowerCase().includes(query);
        const matchesNote = tx.note?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesCategory && !matchesAccount && !matchesTag && !matchesNote) {
          return false;
        }
      }

      // Filter chips
      if (activeFilter === 'expense') return tx.type === 'expense';
      if (activeFilter === 'income') return tx.type === 'income';
      if (activeFilter === 'food') return tx.category.includes('食') || tx.category.includes('餐');
      if (activeFilter === 'transport') return tx.category.includes('交通') || tx.category.includes('通勤');
      if (activeFilter === 'bills') return tx.category.includes('水電') || tx.category.includes('生活');
      return true;
    });
  }, [transactions, searchQuery, activeFilter]);

  // Group transactions by dateDisplay
  const groupedTransactions = useMemo(() => {
    const groups: { [key: string]: Transaction[] } = {};
    filteredTransactions.forEach((tx) => {
      const groupKey = tx.dateDisplay;
      if (!groups[groupKey]) {
        groups[groupKey] = [];
      }
      groups[groupKey].push(tx);
    });
    return groups;
  }, [filteredTransactions]);

  // Financial calculations
  const totalExpense = 18450;
  const totalIncome = 65000;
  const netSavings = 46550;
  const totalBudget = 44000;
  const remainingBudget = 25550;
  const budgetUsagePercent = ((totalExpense / totalBudget) * 100).toFixed(1);

  return (
    <div className="flex flex-col w-full gap-4 pb-12">
      {/* Monthly Financial Pulse Summary Card */}
      <section
        className={`rounded-[20px] p-4 ${
          darkMode
            ? 'bg-[#161c18] border border-[#28332a] shadow-[0_4px_16px_rgba(0,0,0,0.25)]'
            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
        } flex flex-col gap-3.5`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="material-symbols-outlined text-[#34d399] text-[20px]">calendar_month</span>
            <button
              type="button"
              className={`flex items-center space-x-1 text-sm font-bold ${
                darkMode ? 'text-[#e0e3df] hover:text-[#34d399]' : 'text-neutral-900 hover:text-[#346247]'
              } transition-colors`}
            >
              <span>2026年 09月</span>
              <span className="material-symbols-outlined text-[16px] text-[#88938b]">arrow_drop_down</span>
            </button>
          </div>

          <div
            className={`flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full ${
              darkMode ? 'bg-[#1e2621] border border-[#28332a]' : 'bg-emerald-50 border border-emerald-100'
            } text-[11px] font-semibold`}
          >
            <span className="w-2 h-2 rounded-full bg-[#34d399] animate-pulse" />
            <span className={darkMode ? 'text-[#c8d1ca]' : 'text-[#346247]'}>
              共 {transactions.length} 筆明細
            </span>
          </div>
        </div>

        {/* 3-Way Financial Metrics Tile Grid */}
        <div className="grid grid-cols-3 gap-2">
          {/* Total Expense */}
          <div
            className={`flex flex-col p-2.5 rounded-2xl ${
              darkMode ? 'bg-[#1c221e] border border-[#28332a]/50' : 'bg-red-50/70'
            }`}
          >
            <div className="flex items-center space-x-1 text-[11px] text-[#88938b]">
              <span className="material-symbols-outlined text-[14px] text-[#fb7185]">trending_down</span>
              <span>本月總支出</span>
            </div>
            <span className="text-sm sm:text-base font-bold text-[#fb7185] mt-1 font-mono tracking-tight">
              -${totalExpense.toLocaleString()}
            </span>
            <span className="text-[10px] text-[#88938b] mt-0.5">預算內 · 42%</span>
          </div>

          {/* Total Income */}
          <div
            className={`flex flex-col p-2.5 rounded-2xl ${
              darkMode ? 'bg-[#1c221e] border border-[#28332a]/50' : 'bg-emerald-50/70'
            }`}
          >
            <div className="flex items-center space-x-1 text-[11px] text-[#88938b]">
              <span className="material-symbols-outlined text-[14px] text-[#34d399]">trending_up</span>
              <span>本月總收入</span>
            </div>
            <span className="text-sm sm:text-base font-bold text-[#34d399] mt-1 font-mono tracking-tight">
              +${totalIncome.toLocaleString()}
            </span>
            <span className="text-[10px] text-[#34d399]/80 mt-0.5">已達預期 100%</span>
          </div>

          {/* Net Savings */}
          <div
            className={`flex flex-col p-2.5 rounded-2xl ${
              darkMode ? 'bg-[#1c221e] border border-[#28332a]/50' : 'bg-teal-50/70'
            }`}
          >
            <div className="flex items-center space-x-1 text-[11px] text-[#88938b]">
              <span className="material-symbols-outlined text-[14px] text-[#5af0b3]">savings</span>
              <span>淨儲蓄差額</span>
            </div>
            <span className="text-sm sm:text-base font-bold text-[#5af0b3] mt-1 font-mono tracking-tight">
              +${netSavings.toLocaleString()}
            </span>
            <span className="text-[10px] text-[#5af0b3]/80 mt-0.5">儲蓄率 71.6%</span>
          </div>
        </div>

        {/* Micro Progress Strip */}
        <div className="w-full flex flex-col gap-1 pt-1">
          <div className="flex justify-between text-[11px] text-[#88938b]">
            <span>預算消耗狀態 (上限 ${totalBudget.toLocaleString()})</span>
            <span className="font-semibold text-[#34d399]">剩餘 ${remainingBudget.toLocaleString()}</span>
          </div>
          <div
            className={`w-full h-2 rounded-full ${
              darkMode ? 'bg-[#222b24]' : 'bg-neutral-200'
            } overflow-hidden`}
          >
            <div
              className="h-full bg-gradient-to-r from-[#10b981] to-[#34d399] rounded-full transition-all duration-500"
              style={{ width: `${budgetUsagePercent}%` }}
            />
          </div>
        </div>
      </section>

      {/* Quick Filter Pills & View Customizers */}
      <section className="flex items-center space-x-2 overflow-x-auto no-scrollbar py-0.5">
        <button
          type="button"
          onClick={() => setActiveFilter('all')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            activeFilter === 'all'
              ? darkMode
                ? 'bg-[#10b981] text-[#002111] shadow-sm'
                : 'bg-[#346247] text-white shadow-sm'
              : darkMode
              ? 'bg-[#161c18] border border-[#28332a] text-[#c8d1ca] hover:bg-[#1f2721]'
              : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <span>全部 (All)</span>
          <span
            className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-bold ${
              activeFilter === 'all'
                ? darkMode
                  ? 'bg-[#002111]/20 text-[#002111]'
                  : 'bg-white/20 text-white'
                : 'bg-[#88938b]/20 text-[#88938b]'
            }`}
          >
            {transactions.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveFilter('expense')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            activeFilter === 'expense'
              ? 'bg-[#fb7185] text-white font-bold'
              : darkMode
              ? 'bg-[#161c18] border border-[#28332a] text-[#c8d1ca] hover:bg-[#1f2721]'
              : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-[#fb7185]" />
          <span>支出 (Expenses)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveFilter('income')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            activeFilter === 'income'
              ? 'bg-[#34d399] text-[#002111] font-bold'
              : darkMode
              ? 'bg-[#161c18] border border-[#28332a] text-[#c8d1ca] hover:bg-[#1f2721]'
              : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-[#34d399]" />
          <span>收入 (Income)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveFilter('food')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            activeFilter === 'food'
              ? 'bg-[#f59e0b] text-white font-bold'
              : darkMode
              ? 'bg-[#161c18] border border-[#28332a] text-[#c8d1ca]'
              : 'bg-white border border-neutral-200 text-neutral-700'
          }`}
        >
          <span className="material-symbols-outlined text-[15px] text-[#f59e0b]">restaurant</span>
          <span>餐飲</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveFilter('transport')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            activeFilter === 'transport'
              ? 'bg-[#38bdf8] text-white font-bold'
              : darkMode
              ? 'bg-[#161c18] border border-[#28332a] text-[#c8d1ca]'
              : 'bg-white border border-neutral-200 text-neutral-700'
          }`}
        >
          <span className="material-symbols-outlined text-[15px] text-[#38bdf8]">commute</span>
          <span>交通</span>
        </button>

        <button
          type="button"
          onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center space-x-1 whitespace-nowrap active:scale-95 transition-all ${
            darkMode
              ? 'bg-[#1c221e] border border-[#28332a] text-[#88938b]'
              : 'bg-neutral-100 border border-neutral-200 text-neutral-600'
          }`}
        >
          <span className="material-symbols-outlined text-[15px]">swap_vert</span>
          <span>{sortOrder === 'desc' ? '日期新到舊' : '日期舊到新'}</span>
        </button>
      </section>

      {/* Daily Transactions Timeline Feed */}
      <section className="flex flex-col gap-4">
        {Object.keys(groupedTransactions).length === 0 ? (
          <div
            className={`p-8 text-center rounded-2xl ${
              darkMode ? 'bg-[#161c18] text-[#88938b]' : 'bg-white text-neutral-500'
            }`}
          >
            <span className="material-symbols-outlined text-4xl mb-2 text-[#88938b]/50">
              search_off
            </span>
            <p className="text-sm">無符合條件的記帳明細</p>
          </div>
        ) : (
          Object.keys(groupedTransactions).map((dateLabel) => {
            const txList: Transaction[] = groupedTransactions[dateLabel];
            // Calculate day total
            const dayExpense = txList
              .filter((t) => t.type === 'expense')
              .reduce((acc, t) => acc + t.amount, 0);
            const dayIncome = txList
              .filter((t) => t.type === 'income')
              .reduce((acc, t) => acc + t.amount, 0);

            return (
              <div key={dateLabel} className="flex flex-col gap-1.5">
                {/* Date Header Ribbon */}
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#34d399]" />
                    <span
                      className={`text-xs font-bold ${
                        darkMode ? 'text-[#e0e3df]' : 'text-neutral-800'
                      }`}
                    >
                      {dateLabel}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-[11px] font-medium">
                    {dayExpense > 0 && (
                      <span className="text-[#fb7185]">支 -${dayExpense.toLocaleString()}</span>
                    )}
                    {dayIncome > 0 && (
                      <span className="text-[#34d399]">收 +${dayIncome.toLocaleString()}</span>
                    )}
                  </div>
                </div>

                {/* Day's Transactions Container */}
                <div className="flex flex-col gap-1.5">
                  {txList.map((tx) => {
                    const isExpense = tx.type === 'expense';
                    return (
                      <div
                        key={tx.id}
                        className={`rounded-[20px] p-3.5 ${
                          darkMode
                            ? 'bg-[#161c18] border border-[#28332a] shadow-[0_2px_8px_rgba(0,0,0,0.2)] hover:border-[#34d399]/40'
                            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)] hover:border-[#346247]/40'
                        } transition-all flex items-center justify-between group active:scale-[0.99] cursor-pointer`}
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <div
                            className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform"
                            style={{
                              backgroundColor: tx.categoryBg,
                              color: tx.categoryColor,
                            }}
                          >
                            <span
                              className="material-symbols-outlined text-[22px]"
                              style={{
                                fontVariationSettings: tx.type === 'income' ? "'FILL' 1" : "'FILL' 0",
                              }}
                            >
                              {tx.categoryIcon}
                            </span>
                          </div>

                          <div className="flex flex-col min-w-0">
                            <div className="flex items-center space-x-1.5">
                              <span
                                className={`text-xs font-bold truncate ${
                                  darkMode ? 'text-[#e0e3df]' : 'text-neutral-900'
                                }`}
                              >
                                {tx.title}
                              </span>
                              {tx.tag && (
                                <span
                                  className={`text-[10px] px-1.5 py-0.2 rounded font-medium ${
                                    tx.type === 'income'
                                      ? 'bg-[#065f46]/40 text-[#34d399] border border-[#10b981]/30'
                                      : darkMode
                                      ? 'bg-[#1e2621] text-[#9aa59d] border border-[#28332a]'
                                      : 'bg-neutral-100 text-neutral-600'
                                  }`}
                                >
                                  {tx.tag}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center space-x-1 text-[11px] text-[#88938b] truncate mt-0.5">
                              <span>{tx.account}</span>
                              <span>·</span>
                              <span>{tx.time}</span>
                              {tx.note && (
                                <>
                                  <span>·</span>
                                  <span className="truncate">{tx.note}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-end shrink-0 pl-2">
                          <span
                            className={`text-sm font-bold font-mono tracking-tight ${
                              isExpense ? 'text-[#fb7185]' : 'text-[#34d399]'
                            }`}
                          >
                            {isExpense ? `-$${tx.amount.toLocaleString()}` : `+$${tx.amount.toLocaleString()}`}
                          </span>
                          <span className="text-[10px] text-[#88938b]">
                            {tx.type === 'income' ? '主動收入' : tx.category}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </section>

      {/* Friendly Ledger Motivation Insight */}
      <section
        className={`rounded-[20px] p-3.5 flex items-center space-x-3 ${
          darkMode
            ? 'bg-[#161c18] border border-[#28332a]'
            : 'bg-emerald-50/70 border border-emerald-100'
        }`}
      >
        <div
          className={`w-9 h-9 rounded-full ${
            darkMode
              ? 'bg-[#10b981]/15 border border-[#10b981]/30 text-[#34d399]'
              : 'bg-emerald-100 text-[#346247]'
          } flex items-center justify-center shrink-0`}
        >
          <span className="material-symbols-outlined text-[19px]">auto_awesome</span>
        </div>
        <div className="flex flex-col">
          <span
            className={`text-xs font-bold ${
              darkMode ? 'text-[#e0e3df]' : 'text-neutral-900'
            }`}
          >
            記帳節奏極佳！
          </span>
          <span
            className={`text-[11px] ${
              darkMode ? 'text-[#88938b]' : 'text-neutral-600'
            }`}
          >
            已連續記錄 18 天，比上月同期節省約 $3,200 額外支出。
          </span>
        </div>
      </section>
    </div>
  );
};
