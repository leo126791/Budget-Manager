import React from 'react';
import { NavigationTab } from '../types';

interface AppHeaderProps {
  currentTab: NavigationTab;
  darkMode: boolean;
  onOpenKotlinModal: () => void;
  onNavigateTab: (tab: NavigationTab) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  currentTab,
  darkMode,
  onOpenKotlinModal,
  onNavigateTab,
  searchQuery,
  onSearchChange,
}) => {
  const isSettings = currentTab === 'settings';

  return (
    <header
      id="app-header"
      className={`px-4 pt-1 pb-3 ${
        darkMode
          ? 'bg-[#101412]/90 border-b border-white/[0.06]'
          : 'bg-[#f8f9fa]/95 border-b border-neutral-200/80'
      } backdrop-blur-xl sticky top-0 z-30 transition-colors`}
    >
      <div className="flex items-center justify-between pb-2">
        <div className="flex items-center space-x-2.5">
          <div
            className={`w-9 h-9 rounded-xl ${
              darkMode
                ? 'bg-amber-500/15 border border-amber-500/20 shadow-sm'
                : 'bg-amber-100 border border-amber-200 shadow-sm'
            } flex items-center justify-center text-lg`}
          >
            <img
              src="https://lh3.googleusercontent.com/aida/AEtjO1X098x0ENATeYWqRCwoWn1lQcS3L-L3SlZtebt6vZjq7GSvDUwJHV9VvcNjOKA9p2s7iW_mN9lEUCG049Kt3HdiYYZUaKyL4Y2oKe0otv2fjy9Zi2rVKC1oLv8hj9SfX8a5UrRqRkQb60vDTPVOwpHYRZA-pEXCvoKcnR0IfCAGgmFXtRE8VmZEgHosY1JCfnb-VZTmT9aAwAnparPM_Na1p8UbhqBlbsXRxqRe_MYpWKtVz4vZCeGOtpCA"
              alt="Golden Piggy Bank"
              className="h-6 w-auto object-contain drop-shadow"
              onError={(e) => {
                // fallback to material icon
                const target = e.currentTarget;
                target.style.display = 'none';
                if (target.parentElement) {
                  const span = document.createElement('span');
                  span.className = 'material-symbols-outlined text-amber-500 text-[22px] fill';
                  span.innerText = 'savings';
                  target.parentElement.appendChild(span);
                }
              }}
            />
          </div>
          <div>
            <h1
              className={`text-[17px] font-bold tracking-tight leading-tight ${
                darkMode ? 'text-[#f1f5f9]' : 'text-neutral-900'
              }`}
            >
              {isSettings ? '設定 (Settings)' : 'Budget Manager'}
            </h1>
            <p
              className={`text-[11px] font-medium leading-none mt-0.5 ${
                darkMode ? 'text-[#88938b]' : 'text-neutral-500'
              }`}
            >
              {isSettings ? '系統偏好與自訂管理' : 'Dashboard'}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5">
          {!isSettings && (
            <button
              id="month-selector-btn"
              type="button"
              className={`h-8 px-2.5 rounded-full ${
                darkMode
                  ? 'bg-[#1c241f] border border-white/5 text-[#e0e3df] hover:bg-[#253029]'
                  : 'bg-white border border-neutral-200 text-neutral-800 hover:bg-neutral-50'
              } flex items-center space-x-1 text-xs font-semibold shadow-sm active:scale-95 transition-all`}
            >
              <span className="material-symbols-outlined text-[15px] text-[#34d399]">
                calendar_month
              </span>
              <span>2026年 09月</span>
              <span className="material-symbols-outlined text-[13px] text-[#88938b]">
                arrow_drop_down
              </span>
            </button>
          )}

          {/* Android Studio Kotlin button */}
          <button
            id="android-studio-btn"
            type="button"
            onClick={onOpenKotlinModal}
            className="flex items-center space-x-1 px-2.5 py-1 rounded-full bg-[#10b981]/15 hover:bg-[#10b981]/25 border border-[#10b981]/30 text-[#34d399] text-xs font-bold shadow-sm active:scale-95 transition-all"
            title="開啟 Android Studio Kotlin 原始碼專案架構"
          >
            <span className="material-symbols-outlined text-[15px]">code</span>
            <span className="hidden sm:inline">Kotlin 代碼</span>
          </button>

          {isSettings ? (
            <button
              type="button"
              className={`w-8 h-8 rounded-full ${
                darkMode
                  ? 'bg-[#1a221d] text-[#9aa59d] border border-white/10 hover:bg-[#222c25]'
                  : 'bg-white text-neutral-600 border border-neutral-200 hover:bg-neutral-100'
              } flex items-center justify-center shadow-sm active:scale-95 transition`}
              title="說明與支援"
            >
              <span className="material-symbols-outlined text-[18px]">help_outline</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigateTab('settings')}
              className={`w-8 h-8 rounded-full ${
                darkMode
                  ? 'bg-[#1a221d] text-[#88938b] hover:text-[#e0e3df] hover:bg-[#222c25]'
                  : 'bg-white text-neutral-600 hover:bg-neutral-100'
              } flex items-center justify-center transition-colors`}
              title="設定"
            >
              <span className="material-symbols-outlined text-[20px]">settings</span>
            </button>
          )}
        </div>
      </div>

      {/* Search Input on Dashboard & Transactions */}
      {!isSettings && (
        <div className="w-full mt-1">
          <div
            className={`h-10 px-3.5 ${
              darkMode
                ? 'bg-[#161c18] border border-white/5 text-[#e0e3df]'
                : 'bg-white border border-neutral-200/80 text-neutral-800'
            } rounded-2xl flex items-center space-x-2.5 shadow-sm transition-all focus-within:ring-1 focus-within:ring-[#34d399]/50`}
          >
            <span
              className={`material-symbols-outlined text-[19px] ${
                darkMode ? 'text-[#88938b]' : 'text-neutral-400'
              }`}
            >
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="搜尋備註類別或帳戶..."
              className="w-full bg-transparent text-[13px] placeholder-[#88938b]/60 focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="text-[#88938b] hover:text-white"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
