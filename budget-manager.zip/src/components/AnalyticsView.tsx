import React, { useState } from 'react';
import { Category } from '../types';

interface AnalyticsViewProps {
  darkMode: boolean;
  categories: Category[];
  onExportCsv: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  darkMode,
  categories,
  onExportCsv,
}) => {
  const [period, setPeriod] = useState<'week' | 'month' | 'quarter' | 'year'>('month');

  return (
    <div className="flex flex-col w-full gap-4 pb-12">
      {/* Sub-Header / Period Switcher Section */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <h2
              className={`text-base font-bold ${
                darkMode ? 'text-white' : 'text-neutral-900'
              }`}
            >
              統計分析
            </h2>
            <span
              className={`text-xs ${
                darkMode ? 'text-[#88938b]' : 'text-neutral-500'
              }`}
            >
              財務健康與趨勢洞察
            </span>
          </div>
          <button
            type="button"
            onClick={onExportCsv}
            className={`h-8 px-3 rounded-full ${
              darkMode
                ? 'bg-[#1a221d] border border-white/5 text-[#88938b] hover:text-[#e1e3e0]'
                : 'bg-white border border-neutral-200 text-neutral-700 hover:bg-neutral-50'
            } flex items-center space-x-1 text-xs font-semibold shadow-sm active:scale-95 transition-all`}
          >
            <span className="material-symbols-outlined text-[16px] text-[#34d399]">
              download
            </span>
            <span>匯出報表</span>
          </button>
        </div>

        {/* Time Period Segmented Control */}
        <div
          className={`flex p-1 ${
            darkMode ? 'bg-[#161c18] border border-white/5' : 'bg-neutral-200/60'
          } rounded-full shadow-inner`}
        >
          {(['week', 'month', 'quarter', 'year'] as const).map((p) => {
            const labels = {
              week: '週',
              month: '月',
              quarter: '季',
              year: '年',
            };
            const isActive = period === p;
            return (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={`flex-1 py-1.5 rounded-full text-center text-xs font-semibold transition-all ${
                  isActive
                    ? darkMode
                      ? 'bg-[#34d399] text-[#003825] shadow-md'
                      : 'bg-[#346247] text-white shadow-sm'
                    : darkMode
                    ? 'text-[#88938b] hover:text-white'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {labels[p]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Hero Overview Summary Card */}
      <section
        className={`w-full p-4 rounded-[20px] ${
          darkMode
            ? 'bg-[#1a221d] border border-white/5 shadow-lg'
            : 'bg-white border border-neutral-200/80 shadow-[0_4px_16px_rgba(52,98,71,0.08)]'
        } relative overflow-hidden flex flex-col gap-3`}
      >
        <div className="absolute -right-10 -top-10 w-36 h-36 rounded-full bg-[#34d399]/10 pointer-events-none blur-xl" />

        <div className="flex items-start justify-between">
          <div className="flex flex-col">
            <span
              className={`text-xs ${
                darkMode ? 'text-[#88938b]' : 'text-neutral-500'
              }`}
            >
              當月累積淨儲蓄
            </span>
            <div className="flex items-baseline gap-1.5 mt-0.5">
              <span className="text-2xl sm:text-3xl font-bold text-[#34d399] font-mono">
                +$46,550
              </span>
              <span className="text-xs font-semibold text-[#34d399]">TWD</span>
            </div>
          </div>
          <div
            className={`px-2 py-1 rounded-full ${
              darkMode
                ? 'bg-[#34d399]/15 border border-[#34d399]/30 text-[#34d399]'
                : 'bg-emerald-100 text-[#346247]'
            } flex items-center space-x-1 text-xs font-bold`}
          >
            <span className="material-symbols-outlined text-[15px]">savings</span>
            <span>儲蓄率 71.6%</span>
          </div>
        </div>

        {/* Financial Metrics Ratio Comparison */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <div
            className={`p-3 rounded-xl ${
              darkMode ? 'bg-[#121714] border border-white/5' : 'bg-red-50/70'
            } flex flex-col gap-0.5`}
          >
            <div className="flex items-center space-x-1 text-xs text-[#88938b]">
              <span className="w-2 h-2 rounded-full bg-[#fb7185]" />
              <span>總支出 (Expense)</span>
            </div>
            <span className="text-lg font-bold text-[#fb7185] font-mono tracking-tight">
              $18,450
            </span>
            <div className="flex items-center space-x-0.5 text-[#34d399] text-[11px] mt-0.5 font-medium">
              <span className="material-symbols-outlined text-[13px]">arrow_downward</span>
              <span>比上月省 14.2%</span>
            </div>
          </div>

          <div
            className={`p-3 rounded-xl ${
              darkMode ? 'bg-[#121714] border border-white/5' : 'bg-emerald-50/70'
            } flex flex-col gap-0.5`}
          >
            <div className="flex items-center space-x-1 text-xs text-[#88938b]">
              <span className="w-2 h-2 rounded-full bg-[#34d399]" />
              <span>總收入 (Income)</span>
            </div>
            <span className="text-lg font-bold text-[#34d399] font-mono tracking-tight">
              $65,000
            </span>
            <div className="flex items-center space-x-0.5 text-[#88938b] text-[11px] mt-0.5">
              <span className="material-symbols-outlined text-[13px]">check</span>
              <span>薪資與利息入帳</span>
            </div>
          </div>
        </div>
      </section>

      {/* Category Breakdown & Donut Chart */}
      <section
        className={`w-full p-4 rounded-[20px] ${
          darkMode
            ? 'bg-[#1a221d] border border-white/5 shadow-md'
            : 'bg-white border border-neutral-200/80 shadow-[0_2px_8px_rgba(52,98,71,0.05)]'
        } flex flex-col gap-3`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1.5">
            <span className="material-symbols-outlined text-[#34d399] text-[20px]">pie_chart</span>
            <span
              className={`text-sm font-bold ${
                darkMode ? 'text-white' : 'text-neutral-900'
              }`}
            >
              支出類別佔比
            </span>
          </div>
          <span
            className={`text-xs ${
              darkMode ? 'text-[#88938b]' : 'text-neutral-500'
            }`}
          >
            共 6 個類別
          </span>
        </div>

        {/* Donut Chart & Legend Stats */}
        <div className="flex items-center gap-4 py-1">
          <div className="relative w-32 h-32 shrink-0 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              {/* Track */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke={darkMode ? '#26332b' : '#E1E3E4'}
                strokeWidth="4.5"
              />
              {/* Food 38% */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke="#fb7185"
                strokeDasharray="33.4 88"
                strokeDashoffset="0"
                strokeWidth="4.5"
              />
              {/* Housing 25% */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke="#eab308"
                strokeDasharray="22 88"
                strokeDashoffset="-33.4"
                strokeWidth="4.5"
              />
              {/* Commute 15% */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke="#34d399"
                strokeDasharray="13.2 88"
                strokeDashoffset="-55.4"
                strokeWidth="4.5"
              />
              {/* Shopping 12% */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke="#10b981"
                strokeDasharray="10.5 88"
                strokeDashoffset="-68.6"
                strokeWidth="4.5"
              />
              {/* Health 10% */}
              <circle
                cx="18"
                cy="18"
                fill="transparent"
                r="14"
                stroke="#64748b"
                strokeDasharray="8.9 88"
                strokeDashoffset="-79.1"
                strokeWidth="4.5"
              />
            </svg>

            <div className="absolute flex flex-col items-center justify-center text-center">
              <span
                className={`text-[10px] leading-none ${
                  darkMode ? 'text-[#88938b]' : 'text-neutral-500'
                }`}
              >
                本月總額
              </span>
              <span
                className={`text-sm font-bold font-mono mt-0.5 ${
                  darkMode ? 'text-white' : 'text-neutral-900'
                }`}
              >
                $18,450
              </span>
            </div>
          </div>

          {/* Quick Summary List */}
          <div className="flex flex-col gap-1.5 flex-1 min-w-0 text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full bg-[#fb7185] shrink-0" />
                <span className={`truncate ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  食品餐飲
                </span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                38%
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full bg-[#eab308] shrink-0" />
                <span className={`truncate ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  居住水電
                </span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                25%
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full bg-[#34d399] shrink-0" />
                <span className={`truncate ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  交通通勤
                </span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                15%
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1.5 truncate">
                <span className="w-2.5 h-2.5 rounded-full bg-[#10b981] shrink-0" />
                <span className={`truncate ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  購物娛樂
                </span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                12%
              </span>
            </div>
          </div>
        </div>

        {/* Category Progress Drilldown List */}
        <div className="flex flex-col gap-3 pt-1 border-t border-white/5">
          {/* Item 1 */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-[#fb7185]/15 text-[#fb7185] flex items-center justify-center">
                  <span className="material-symbols-outlined text-[16px]">restaurant</span>
                </div>
                <span className={`font-medium ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  食品餐飲
                </span>
                <span className="text-[10px] text-[#fb7185]">+3% 略增</span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                $7,011
              </span>
            </div>
            <div
              className={`w-full h-2 rounded-full ${
                darkMode ? 'bg-[#27342b]' : 'bg-neutral-200'
              } overflow-hidden`}
            >
              <div className="h-full bg-[#fb7185] rounded-full" style={{ width: '38%' }} />
            </div>
          </div>

          {/* Item 2 */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-[#eab308]/20 text-[#facc15] flex items-center justify-center">
                  <span className="material-symbols-outlined text-[16px]">cottage</span>
                </div>
                <span className={`font-medium ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  居住水電
                </span>
                <span className="text-[10px] text-[#34d399]">持平固定</span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                $4,612
              </span>
            </div>
            <div
              className={`w-full h-2 rounded-full ${
                darkMode ? 'bg-[#27342b]' : 'bg-neutral-200'
              } overflow-hidden`}
            >
              <div className="h-full bg-[#eab308] rounded-full" style={{ width: '25%' }} />
            </div>
          </div>

          {/* Item 3 */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-[#34d399]/15 text-[#34d399] flex items-center justify-center">
                  <span className="material-symbols-outlined text-[16px]">directions_subway</span>
                </div>
                <span className={`font-medium ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  交通通勤
                </span>
                <span className="text-[10px] text-[#34d399]">-5% 節省</span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                $2,767
              </span>
            </div>
            <div
              className={`w-full h-2 rounded-full ${
                darkMode ? 'bg-[#27342b]' : 'bg-neutral-200'
              } overflow-hidden`}
            >
              <div className="h-full bg-[#34d399] rounded-full" style={{ width: '15%' }} />
            </div>
          </div>

          {/* Item 4 */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-[#10b981]/20 text-[#34d399] flex items-center justify-center">
                  <span className="material-symbols-outlined text-[16px]">shopping_bag</span>
                </div>
                <span className={`font-medium ${darkMode ? 'text-[#e1e3e0]' : 'text-neutral-800'}`}>
                  購物娛樂
                </span>
                <span className="text-[10px] text-[#fb7185]">+10% 超標</span>
              </div>
              <span className={`font-bold font-mono ${darkMode ? 'text-white' : 'text-neutral-900'}`}>
                $2,214
              </span>
            </div>
            <div
              className={`w-full h-2 rounded-full ${
                darkMode ? 'bg-[#27342b]' : 'bg-neutral-200'
              } overflow-hidden`}
            >
              <div className="h-full bg-[#34d399] rounded-full" style={{ width: '12%' }} />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
